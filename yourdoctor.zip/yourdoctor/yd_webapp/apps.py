from django.apps import AppConfig


class YdWebappConfig(AppConfig):
    name = 'yd_webapp'
